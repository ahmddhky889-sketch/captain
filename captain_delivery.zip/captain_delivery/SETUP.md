# تشغيل المشروع

يلزمك Flutter مثبّتًا على جهازك (https://docs.flutter.dev/get-started/install).

## ١. توليد ملفات الأندرويد والآيفون
من داخل مجلد المشروع:

```
flutter create --org com.captain --project-name captain_delivery .
flutter pub get
```

إن ظهر الملف `test/widget_test.dart` فاحذفه، لأنه يشير إلى تطبيق تجريبي غير موجود.

## ٢. صلاحية الموقع

### أندرويد
في الملف `android/app/src/main/AndroidManifest.xml` أضف داخل وسم `manifest` وقبل وسم `application`:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```

وغيّر الاسم الظاهر إلى `android:label="دليفري القبطان"`.

### آيفون
في الملف `ios/Runner/Info.plist` أضف:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>نحتاج موقعك لنعرض لك المحلات القريبة ونقدّر وقت وصول طلبك.</string>
```

## ٣. التشغيل

```
flutter run
```

## ملاحظات
- الخط Cairo يُحمَّل من الإنترنت عند أول تشغيل، وبديله IBM Plex Sans Arabic. قبل الإطلاق نضمّن الخطوط داخل التطبيق.
- المحلات الحالية تجريبية (`lib/data/demo_shops.dart`)، وتظهر قريبة من موقعك. عطّلها بجعل `kUseDemoData = false`.
- زر "إضافة محل" يظهر الآن في وضع التطوير فقط. قبل الإطلاق نربطه بتسجيل دخول حقيقي لك وبقاعدة بيانات محمية على الخادم، لأن حماية "المالك فقط" لا تكتمل من داخل التطبيق وحده.
