import 'dart:math' as math;

import 'models/shop.dart';
import 'models/shop_category.dart';

/// بيانات تجريبية لتجربة الشاشة قبل أن تضيف أنت المحلات الحقيقية.
/// اجعلها false عند الإطلاق.
const bool kUseDemoData = true;

class _Seed {
  const _Seed(this.name, this.category, this.dxKm, this.dyKm);

  final String name;
  final ShopCategory category;

  /// الإزاحة عن موقع المستخدم بالكيلومتر (شرقًا وشمالًا).
  final double dxKm;
  final double dyKm;
}

class DemoShops {
  DemoShops._();

  static const _seeds = <_Seed>[
    _Seed('هايبر النخيل', ShopCategory.hyper, 0.8, 0.4),
    _Seed('هايبر الشراع', ShopCategory.hyper, -2.1, 1.3),
    _Seed('مطعم المرسى', ShopCategory.restaurant, 0.3, -0.6),
    _Seed('مطعم الأمواج', ShopCategory.restaurant, 1.9, 1.1),
    _Seed('مقهى الفنار', ShopCategory.cafe, -0.5, 0.2),
    _Seed('كافيه الشاطئ', ShopCategory.cafe, 2.6, -1.4),
    _Seed('خضار الواحة', ShopCategory.vegetables, -1.2, -0.9),
    _Seed('فواكه الجزيرة', ShopCategory.fruits, 0.6, 1.7),
    _Seed('عصائر الميناء', ShopCategory.beverages, -0.9, 0.8),
    _Seed('حلويات اللؤلؤ', ShopCategory.sweets, 1.4, -0.3),
    _Seed('أزياء الخليج', ShopCategory.clothes, 3.2, 0.9),
    _Seed('صيدلية السلامة', ShopCategory.pharmacy, -0.2, -0.4),
    _Seed('مخبز الفجر', ShopCategory.bakery, 0.9, 0.9),
    _Seed('لحوم الأمانة', ShopCategory.meat, -1.7, -0.2),
    _Seed('بيت الأدوات', ShopCategory.home, 2.2, 2.0),
    _Seed('عالم الصغار', ShopCategory.kids, -2.8, 0.6),
  ];

  /// يبني المحلات التجريبية حول [lat] و[lng]، أو بدون إحداثيات إن لم يتوفر الموقع.
  static List<Shop> build({double? lat, double? lng}) {
    return [
      for (var i = 0; i < _seeds.length; i++) _toShop(i, _seeds[i], lat, lng),
    ];
  }

  static Shop _toShop(int index, _Seed s, double? lat, double? lng) {
    double? shopLat;
    double? shopLng;
    if (lat != null && lng != null) {
      shopLat = lat + s.dyKm / 110.57;
      shopLng = lng + s.dxKm / (111.32 * math.cos(lat * math.pi / 180));
    }
    return Shop(
      id: 'demo-$index',
      name: s.name,
      category: s.category,
      latitude: shopLat,
      longitude: shopLng,
    );
  }
}
