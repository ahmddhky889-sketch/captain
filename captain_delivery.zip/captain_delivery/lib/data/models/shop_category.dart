import 'package:flutter/material.dart';

import '../../core/utils/arabic_text.dart';

/// أقسام المحلات بالترتيب المتفق عليه (من اليمين لليسار في الشريط).
/// الأقسام الأربعة الأخيرة هي "الاختيارات الأخرى الروتينية" ويمكن تعديلها.
enum ShopCategory {
  hyper('الهايبرات', 'هايبر', Icons.storefront_outlined,
      ['هايبر', 'هايبرات', 'سوبر ماركت', 'ماركت', 'بقالة']),
  restaurant('المطاعم', 'مطعم', Icons.restaurant_outlined,
      ['مطعم', 'مطاعم', 'اكل', 'وجبات', 'مشويات', 'برجر', 'بيتزا']),
  cafe('المقاهي', 'مقهى', Icons.local_cafe_outlined,
      ['مقهى', 'مقاهي', 'قهوة', 'كافيه', 'كوفي']),
  vegetables('محلات الخضروات', 'محل خضروات', Icons.eco_outlined,
      ['خضروات', 'خضار', 'خضرة']),
  fruits('محلات الفواكه', 'محل فواكه', Icons.local_florist_outlined,
      ['فواكه', 'فاكهة', 'فاكهه']),
  beverages('محلات المشروبات', 'محل مشروبات', Icons.local_drink_outlined,
      ['مشروبات', 'مشروب', 'عصير', 'عصائر']),
  sweets('محلات الحلويات', 'محل حلويات', Icons.cake_outlined,
      ['حلويات', 'حلوى', 'حلو', 'كيك', 'جاتوه']),
  clothes('محلات الملابس', 'محل ملابس', Icons.checkroom_outlined,
      ['ملابس', 'ازياء', 'هدوم', 'لبس']),
  pharmacy('الصيدليات', 'صيدلية', Icons.local_pharmacy_outlined,
      ['صيدلية', 'صيدليات', 'دواء', 'ادوية']),
  bakery('المخابز', 'مخبز', Icons.bakery_dining_outlined,
      ['مخبز', 'مخابز', 'خبز', 'عيش', 'فرن']),
  meat('اللحوم والدواجن', 'محل لحوم', Icons.set_meal_outlined,
      ['لحوم', 'لحمة', 'جزار', 'دواجن', 'فراخ']),
  home('الأدوات المنزلية', 'محل أدوات منزلية', Icons.chair_outlined,
      ['ادوات', 'منزلية', 'مفروشات']),
  kids('مستلزمات الأطفال', 'محل أطفال', Icons.child_care_outlined,
      ['اطفال', 'طفل', 'العاب', 'حفاضات']);

  const ShopCategory(this.label, this.singular, this.icon, this.keywords);

  /// الاسم الظاهر في الشريط.
  final String label;

  /// الاسم المفرد الظاهر على كرت المحل.
  final String singular;
  final IconData icon;

  /// كلمات يبحث بها المستخدم عن هذا القسم.
  final List<String> keywords;

  /// هل تطابق كلمات البحث هذا القسم؟ ([tokens] بعد التوحيد وحذف "ال").
  bool matchesTokens(List<String> tokens) {
    for (final keyword in keywords) {
      final k = normalizeArabic(keyword);
      for (final t in tokens) {
        if (t.length < 2) continue;
        if (k.contains(t) || t.contains(k)) return true;
      }
    }
    return false;
  }
}
