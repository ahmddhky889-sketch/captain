import 'shop_category.dart';

/// محل يضيفه المالك ويعرض منتجاته داخل التطبيق.
class Shop {
  const Shop({
    required this.id,
    required this.name,
    required this.category,
    this.address,
    this.latitude,
    this.longitude,
  });

  final String id;
  final String name;
  final ShopCategory category;
  final String? address;
  final double? latitude;
  final double? longitude;

  bool get hasLocation => latitude != null && longitude != null;
}
