import 'package:flutter/foundation.dart';

import '../core/l10n/app_strings.dart';

/// هل المستخدم الحالي هو مالك التطبيق؟
///
/// مؤقتًا: في وضع التطوير فقط يُعامَل الجهاز كمالك لنجرّب الإضافة.
/// قبل الإطلاق يُستبدل بتسجيل دخول حقيقي لك، مع قواعد حماية على الخادم،
/// لأن منع غير المالك لا يكتمل من داخل التطبيق وحده.
class OwnerSession extends ChangeNotifier {
  OwnerSession._();

  static final OwnerSession instance = OwnerSession._();

  final bool _isOwner = kDebugMode;

  bool get isOwner => _isOwner;
}

/// تُرمى عند محاولة غير المالك إضافة أي شيء.
class NotOwnerException implements Exception {
  const NotOwnerException();

  String get message => AppStrings.cannotAdd;

  @override
  String toString() => message;
}
