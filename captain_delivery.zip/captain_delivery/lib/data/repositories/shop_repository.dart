import 'package:flutter/foundation.dart';

import '../../core/utils/arabic_text.dart';
import '../../services/delivery_estimator.dart';
import '../demo_shops.dart';
import '../models/shop.dart';
import '../models/shop_category.dart';
import '../owner_session.dart';

class ShopSearchResult {
  const ShopSearchResult(this.matches, this.related);

  /// محلات تطابق ما كتبه المستخدم.
  final List<Shop> matches;

  /// محلات قريبة مما بحث عنه.
  final List<Shop> related;

  bool get isEmpty => matches.isEmpty && related.isEmpty;
}

/// مخزن المحلات. حاليًا في الذاكرة فقط، وسيُستبدل بقاعدة بيانات على الخادم
/// ليراها كل المستخدمين ويضيف عليها المالك وحده.
class ShopRepository extends ChangeNotifier {
  ShopRepository._();

  static final ShopRepository instance = ShopRepository._();

  final List<Shop> _shops = [];
  bool _demoSeeded = false;

  List<Shop> get shops => List.unmodifiable(_shops);

  List<Shop> inCategory(ShopCategory category, {double? lat, double? lng}) {
    final list = _shops.where((s) => s.category == category).toList();
    return _sorted(list, lat, lng);
  }

  /// المالك وحده يضيف. غيره يحصل على [NotOwnerException].
  Future<void> addShop(Shop shop) async {
    if (!OwnerSession.instance.isOwner) {
      throw const NotOwnerException();
    }
    _shops.add(shop);
    notifyListeners();
  }

  /// يضيف المحلات التجريبية مرة واحدة فقط.
  void seedDemo({double? lat, double? lng}) {
    if (!kUseDemoData || _demoSeeded) return;
    _demoSeeded = true;
    _shops.addAll(DemoShops.build(lat: lat, lng: lng));
    notifyListeners();
  }

  /// بحث بالاسم والقسم، مع اقتراح محلات قريبة مما بحث عنه.
  ShopSearchResult search(String raw, {double? lat, double? lng}) {
    final query = normalizeArabic(raw);
    if (query.isEmpty) return const ShopSearchResult([], []);

    final tokens = query
        .split(' ')
        .where((t) => t.isNotEmpty)
        .map(stripAl)
        .toList();
    final categories =
        ShopCategory.values.where((c) => c.matchesTokens(tokens)).toSet();

    final byName = <Shop>[];
    final byCategory = <Shop>[];
    for (final shop in _shops) {
      final name = normalizeArabic(shop.name);
      if (tokens.every((t) => name.contains(t))) {
        byName.add(shop);
      } else if (categories.contains(shop.category)) {
        byCategory.add(shop);
      }
    }

    final matches = [
      ..._sorted(byName, lat, lng),
      ..._sorted(byCategory, lat, lng),
    ];

    final matchedIds = matches.map((s) => s.id).toSet();
    final relatedCategories = byName.map((s) => s.category).toSet();
    final related = _shops.where((shop) {
      if (matchedIds.contains(shop.id)) return false;
      if (relatedCategories.contains(shop.category)) return true;
      final name = normalizeArabic(shop.name);
      return tokens.any((t) => t.length >= 3 && name.contains(t.substring(0, 3)));
    }).toList();

    return ShopSearchResult(
      matches,
      _sorted(related, lat, lng).take(6).toList(),
    );
  }

  /// الأقرب أولًا إن عُرف الموقع، وإلا بالاسم.
  List<Shop> _sorted(List<Shop> list, double? lat, double? lng) {
    final result = [...list];
    if (lat != null && lng != null) {
      double distance(Shop s) => s.hasLocation
          ? DeliveryEstimator.distanceKm(lat, lng, s.latitude!, s.longitude!)
          : double.infinity;
      result.sort((a, b) => distance(a).compareTo(distance(b)));
    } else {
      result.sort((a, b) => a.name.compareTo(b.name));
    }
    return result;
  }
}
