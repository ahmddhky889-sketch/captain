import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

enum LocationStatus { checking, granted, denied, deniedForever, serviceOff }

/// يدير إذن الموقع وموقع المستخدم الحالي.
class LocationService extends ChangeNotifier {
  LocationService._();

  static final LocationService instance = LocationService._();

  LocationStatus _status = LocationStatus.checking;
  Position? _position;
  bool _busy = false;

  LocationStatus get status => _status;
  Position? get position => _position;
  double? get lat => _position?.latitude;
  double? get lng => _position?.longitude;

  /// عند فتح التطبيق: نطلب الإذن إن لم يكن ممنوحًا.
  Future<void> requestAtLaunch() => _resolve(askPermission: true);

  /// إعادة المحاولة بطلب الإذن مرة أخرى.
  Future<void> retry() => _resolve(askPermission: true);

  /// فحص هادئ بدون نافذة طلب (مثلًا عند العودة من الإعدادات).
  Future<void> refresh() => _resolve(askPermission: false);

  Future<void> _resolve({required bool askPermission}) async {
    if (_busy) return;
    _busy = true;
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _set(LocationStatus.serviceOff);
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied && askPermission) {
        permission = await Geolocator.requestPermission();
      }

      switch (permission) {
        case LocationPermission.denied:
        case LocationPermission.unableToDetermine:
          _set(LocationStatus.denied);
          return;
        case LocationPermission.deniedForever:
          _set(LocationStatus.deniedForever);
          return;
        case LocationPermission.whileInUse:
        case LocationPermission.always:
          break;
      }

      try {
        _position = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
            timeLimit: Duration(seconds: 12),
          ),
        );
      } catch (_) {
        try {
          _position = await Geolocator.getLastKnownPosition();
        } catch (_) {
          _position = null;
        }
      }
      _set(LocationStatus.granted);
    } finally {
      _busy = false;
    }
  }

  void _set(LocationStatus status) {
    _status = status;
    notifyListeners();
  }
}
