import 'dart:math' as math;

/// تقدير وقت التوصيل من المسافة ووقت اليوم.
class DeliveryEstimator {
  DeliveryEstimator._();

  /// المسافة بين نقطتين بالكيلومتر (معادلة هافرساين).
  static double distanceKm(
    double lat1,
    double lng1,
    double lat2,
    double lng2,
  ) {
    const earthRadiusKm = 6371.0;
    final dLat = _rad(lat2 - lat1);
    final dLng = _rad(lng2 - lng1);
    final a = math.pow(math.sin(dLat / 2), 2) +
        math.cos(_rad(lat1)) *
            math.cos(_rad(lat2)) *
            math.pow(math.sin(dLng / 2), 2);
    return 2 * earthRadiusKm * math.asin(math.min(1.0, math.sqrt(a)));
  }

  /// الدقائق المتوقعة للوصول: تجهيز الطلب + زمن الطريق، مع زيادة وقت الذروة.
  static int minutes(double km, {DateTime? now}) {
    const prepMinutes = 10.0;
    const speedKmh = 22.0;
    const roadFactor = 1.3; // الطريق الفعلي أطول من الخط المستقيم.

    var total = prepMinutes + (km * roadFactor / speedKmh) * 60;

    final hour = (now ?? DateTime.now()).hour;
    final rush = (hour >= 13 && hour < 16) || (hour >= 19 && hour < 22);
    if (rush) total *= 1.25;

    final rounded = (total / 5).ceil() * 5;
    return rounded < 15 ? 15 : rounded;
  }

  static double _rad(double degrees) => degrees * math.pi / 180;
}
