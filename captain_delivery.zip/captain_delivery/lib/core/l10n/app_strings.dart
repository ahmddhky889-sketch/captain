import '../utils/arabic_digits.dart';

/// كل نصوص التطبيق في مكان واحد، بالعربية الفصحى البسيطة ونبرة هادئة مشجعة.
class AppStrings {
  AppStrings._();

  static const appName = 'دليفري القبطان';
  static const greeting = 'أهلًا بك، ماذا نوصّل إليك اليوم؟';

  // التبويبات
  static const tabAccount = 'حسابي';
  static const tabOrders = 'طلباتي';
  static const tabHome = 'الرئيسية';

  // البحث
  static const searchHint = 'ابحث عن مطعم أو هايبر أو مقهى';
  static const searchMatches = 'نتائج مطابقة';
  static const searchRelated = 'قريب مما تبحث عنه';
  static const searchNone = 'لم نجد نتيجة مطابقة الآن، جرّب كلمة أخرى';
  static const clearSearch = 'مسح';

  // الموقع
  static const locationRequired = 'يجب منح إذن الموقع';
  static const locationWhyDenied =
      'نحتاج موقعك لنعرض لك المحلات القريبة ونقدّر وقت وصول طلبك.';
  static const locationWhyForever =
      'يمكنك تفعيل الإذن من إعدادات التطبيق، ثم تعود إلينا بكل سرور.';
  static const locationServiceOff =
      'فعّل خدمة الموقع من إعدادات الهاتف ثم عد إلى التطبيق.';
  static const locationGrant = 'منح الإذن';
  static const locationOpenSettings = 'فتح الإعدادات';
  static const locationChecking = 'نحدد موقعك الآن';

  // المحلات
  static const emptyCategory =
      'لم نضف محلات في هذا القسم بعد، وسيصلك الجديد قريبًا';
  static const shopSectionsSoon =
      'أقسام المحل قيد التجهيز، وسنوافيك بها قريبًا';
  static String eta(int minutes) => 'نحو ${toArabicDigits(minutes)} دقيقة';

  // إضافة المحلات (للمالك فقط)
  static const cannotAdd = 'عذرًا، لا يمكن الإضافة';
  static const addShop = 'إضافة محل';
  static const shopName = 'اسم المحل';
  static const shopCategory = 'القسم';
  static const shopAddress = 'العنوان (اختياري)';
  static const shopUseMyLocation = 'اعتمد موقعي الحالي لهذا المحل';
  static const enterShopName = 'من فضلك اكتب اسم المحل';
  static const save = 'حفظ';
  static const shopAdded = 'تمت إضافة المحل بنجاح';

  // الشاشات الأخرى (مؤقتة)
  static const ordersEmpty =
      'ستظهر طلباتك هنا بعد أول طلب، ونتمنى أن تجد ما يسرك';
  static const accountSoon = 'سنجهّز صفحة حسابك في الخطوة القادمة';

  // الجملة التشجيعية في آخر الشاشة الرئيسية
  static const footerTagline = 'قبطانك دليلك لبر آمن';

  // رسائل تشجيعية للإشعارات وللظهور داخل التطبيق من وقت لآخر
  static const encouragements = <String>[
    'ادخل على دليفري القبطان الآن، ستجد ما يسرك',
    'قبطانك جاهز لتوصيل طلبك متى شئت',
    'نحن هنا متى احتجت إلينا',
    'يومك أجمل مع ما يصلك إلى باب بيتك',
  ];
}
