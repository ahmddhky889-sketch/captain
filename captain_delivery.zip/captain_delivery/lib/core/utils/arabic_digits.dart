import 'package:flutter/services.dart';

const List<String> _eastern = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

/// يحوّل أي أرقام إنجليزية داخل القيمة إلى أرقام شرقية (١٢٣).
/// كل رقم يظهر في التطبيق يمر من هنا.
String toArabicDigits(Object? value) {
  final out = StringBuffer();
  for (final r in '$value'.runes) {
    if (r >= 0x30 && r <= 0x39) {
      out.write(_eastern[r - 0x30]);
    } else {
      out.writeCharCode(r);
    }
  }
  return out.toString();
}

/// رقم عشري بالأرقام الشرقية والفاصلة العربية (٣٫٥).
String formatDecimalAr(double value, {int fractionDigits = 1}) =>
    toArabicDigits(value.toStringAsFixed(fractionDigits)).replaceAll('.', '٫');

/// مسافة مقروءة: بالمتر إن كانت أقل من كيلومتر، وإلا بالكيلومتر.
String formatDistanceAr(double km) {
  if (km < 1) {
    final meters = ((km * 1000) / 10).round() * 10;
    return '${toArabicDigits(meters < 10 ? 10 : meters)} متر';
  }
  if (km >= 100) {
    return '${toArabicDigits(km.round())} كم';
  }
  return '${formatDecimalAr(km)} كم';
}

/// يحوّل ما يكتبه المستخدم من أرقام إلى الشرقية فورًا أثناء الكتابة.
class EasternDigitsFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final converted = toArabicDigits(newValue.text);
    if (converted == newValue.text) return newValue;
    return newValue.copyWith(text: converted);
  }
}
