/// توحيد النص العربي لأغراض البحث: يزيل التشكيل والتطويل،
/// ويوحّد صور الألف والتاء المربوطة والياء، ويحوّل الأرقام إلى إنجليزية للمقارنة.
String normalizeArabic(String input) {
  final buf = StringBuffer();
  for (final r in input.toLowerCase().runes) {
    // التشكيل والتطويل.
    if ((r >= 0x064B && r <= 0x065F) || r == 0x0670 || r == 0x0640) continue;
    switch (r) {
      case 0x0623: // أ
      case 0x0625: // إ
      case 0x0622: // آ
      case 0x0671: // ٱ
        buf.write('ا');
        break;
      case 0x0629: // ة
        buf.write('ه');
        break;
      case 0x0649: // ى
      case 0x0626: // ئ
        buf.write('ي');
        break;
      case 0x0624: // ؤ
        buf.write('و');
        break;
      default:
        if (r >= 0x0660 && r <= 0x0669) {
          buf.write(r - 0x0660);
        } else if (r >= 0x06F0 && r <= 0x06F9) {
          buf.write(r - 0x06F0);
        } else {
          buf.writeCharCode(r);
        }
    }
  }
  return buf.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}

/// يحذف "ال" التعريف من بداية الكلمة الطويلة ليطابق المفرد والجمع بسهولة.
String stripAl(String token) =>
    token.startsWith('ال') && token.length > 3 ? token.substring(2) : token;
