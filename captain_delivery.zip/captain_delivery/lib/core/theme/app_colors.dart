import 'package:flutter/material.dart';

/// ألوان "دليفري القبطان" للوضعين الفاتح والداكن.
/// أي لون في التطبيق يُقرأ من هنا فقط عبر `context.palette`.
@immutable
class AppPalette extends ThemeExtension<AppPalette> {
  const AppPalette({
    required this.background,
    required this.surface,
    required this.border,
    required this.text,
    required this.textMuted,
    required this.primary,
    required this.primaryDeep,
    required this.onPrimary,
    required this.gold,
    required this.goldText,
    required this.error,
  });

  /// خلفية الشاشة.
  final Color background;

  /// خلفية الكروت والعناصر.
  final Color surface;

  /// لون الحدود الواضحة.
  final Color border;

  final Color text;
  final Color textMuted;

  /// الأزرق البحري الفاتح للتعبئة (النص فوقه بلون [onPrimary]).
  final Color primary;

  /// درجة أعمق من الأزرق للنصوص والأيقونات فوق الخلفيات.
  final Color primaryDeep;
  final Color onPrimary;

  /// الذهبي للتميّز (زخارف وحدود).
  final Color gold;

  /// الذهبي الأعمق للنصوص.
  final Color goldText;
  final Color error;

  static const light = AppPalette(
    background: Color(0xFFF3F9FB),
    surface: Color(0xFFFFFFFF),
    border: Color(0xFFBFD8E2),
    text: Color(0xFF12303B),
    textMuted: Color(0xFF4F6B76),
    primary: Color(0xFF3BA7D1),
    primaryDeep: Color(0xFF17728F),
    onPrimary: Color(0xFF072430),
    gold: Color(0xFFB8892B),
    goldText: Color(0xFF7A5A12),
    error: Color(0xFFA8452F),
  );

  static const dark = AppPalette(
    background: Color(0xFF0A1820),
    surface: Color(0xFF112630),
    border: Color(0xFF2F505D),
    text: Color(0xFFE6F2F6),
    textMuted: Color(0xFF9DB8C2),
    primary: Color(0xFF5CC1E0),
    primaryDeep: Color(0xFF7FD0E8),
    onPrimary: Color(0xFF06222C),
    gold: Color(0xFFD9B65F),
    goldText: Color(0xFFE6CC83),
    error: Color(0xFFE0907D),
  );

  @override
  AppPalette copyWith({
    Color? background,
    Color? surface,
    Color? border,
    Color? text,
    Color? textMuted,
    Color? primary,
    Color? primaryDeep,
    Color? onPrimary,
    Color? gold,
    Color? goldText,
    Color? error,
  }) {
    return AppPalette(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      border: border ?? this.border,
      text: text ?? this.text,
      textMuted: textMuted ?? this.textMuted,
      primary: primary ?? this.primary,
      primaryDeep: primaryDeep ?? this.primaryDeep,
      onPrimary: onPrimary ?? this.onPrimary,
      gold: gold ?? this.gold,
      goldText: goldText ?? this.goldText,
      error: error ?? this.error,
    );
  }

  @override
  AppPalette lerp(ThemeExtension<AppPalette>? other, double t) {
    if (other is! AppPalette) return this;
    return AppPalette(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      border: Color.lerp(border, other.border, t)!,
      text: Color.lerp(text, other.text, t)!,
      textMuted: Color.lerp(textMuted, other.textMuted, t)!,
      primary: Color.lerp(primary, other.primary, t)!,
      primaryDeep: Color.lerp(primaryDeep, other.primaryDeep, t)!,
      onPrimary: Color.lerp(onPrimary, other.onPrimary, t)!,
      gold: Color.lerp(gold, other.gold, t)!,
      goldText: Color.lerp(goldText, other.goldText, t)!,
      error: Color.lerp(error, other.error, t)!,
    );
  }
}

extension AppPaletteContext on BuildContext {
  AppPalette get palette => Theme.of(this).extension<AppPalette>()!;
}
