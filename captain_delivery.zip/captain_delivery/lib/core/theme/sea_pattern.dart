import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'app_colors.dart';

/// يرسم دفة سفينة (دائرتان وثمانية أذرع بمقابض) مركزها [center].
/// نصف قطر الرسم الكلي نحو ١٨ × [scale].
void paintHelm(Canvas canvas, Offset center, double scale, Paint paint) {
  canvas.drawCircle(center, 9 * scale, paint);
  canvas.drawCircle(center, 3 * scale, paint);
  for (var i = 0; i < 8; i++) {
    final angle = i * math.pi / 4;
    final dir = Offset(math.cos(angle), math.sin(angle));
    canvas.drawLine(
      center + dir * (3 * scale),
      center + dir * (15 * scale),
      paint,
    );
    canvas.drawCircle(center + dir * (16.5 * scale), 1.4 * scale, paint);
  }
}

void _paintWave(Canvas canvas, Offset o, Paint paint) {
  final path = Path()
    ..moveTo(o.dx - 18, o.dy)
    ..quadraticBezierTo(o.dx - 13.5, o.dy - 6, o.dx - 9, o.dy)
    ..quadraticBezierTo(o.dx - 4.5, o.dy + 6, o.dx, o.dy)
    ..quadraticBezierTo(o.dx + 4.5, o.dy - 6, o.dx + 9, o.dy)
    ..quadraticBezierTo(o.dx + 13.5, o.dy + 6, o.dx + 18, o.dy);
  canvas.drawPath(path, paint);
}

/// النقشة الهندسية الخفيفة: دفات سفن متناوبة تتخللها أمواج.
class SeaPatternPainter extends CustomPainter {
  const SeaPatternPainter({
    required this.waveColor,
    required this.helmColor,
    this.cell = 84,
  });

  final Color waveColor;
  final Color helmColor;
  final double cell;

  @override
  void paint(Canvas canvas, Size size) {
    final helm = Paint()
      ..color = helmColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round;
    final wave = Paint()
      ..color = waveColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round;

    final rows = (size.height / cell).ceil() + 1;
    final cols = (size.width / cell).ceil() + 1;

    for (var r = 0; r < rows; r++) {
      final shift = r.isOdd ? cell / 2 : 0.0;
      for (var c = 0; c < cols; c++) {
        final x = c * cell + shift;
        final y = r * cell;
        paintHelm(canvas, Offset(x, y), 1, helm);
        _paintWave(canvas, Offset(x + cell / 2, y + cell / 2), wave);
      }
    }
  }

  @override
  bool shouldRepaint(covariant SeaPatternPainter old) =>
      old.waveColor != waveColor ||
      old.helmColor != helmColor ||
      old.cell != cell;
}

/// خلفية الشاشة مع النقشة. تُستخدم في كل شاشة.
class SeaBackground extends StatelessWidget {
  const SeaBackground({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Stack(
      children: [
        Positioned.fill(child: ColoredBox(color: p.background)),
        Positioned.fill(
          child: IgnorePointer(
            child: RepaintBoundary(
              child: CustomPaint(
                painter: SeaPatternPainter(
                  waveColor: p.primary.withAlpha(dark ? 30 : 38),
                  helmColor: p.gold.withAlpha(dark ? 36 : 56),
                ),
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}

/// شعار صغير على شكل دفة سفينة.
class WheelMark extends StatelessWidget {
  const WheelMark({super.key, this.size = 32, this.color});

  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final c = color ?? context.palette.gold;
    return CustomPaint(
      size: Size.square(size),
      painter: _WheelPainter(c),
    );
  }
}

class _WheelPainter extends CustomPainter {
  const _WheelPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round;
    paintHelm(canvas, size.center(Offset.zero), size.width / 36, paint);
  }

  @override
  bool shouldRepaint(covariant _WheelPainter old) => old.color != color;
}
