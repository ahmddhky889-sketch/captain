import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

/// الثيم المركزي: الخط والحواف والحدود وألوان الوضعين.
class AppTheme {
  AppTheme._();

  /// نصف قطر حواف الكروت والعناصر الرئيسية.
  static const double radius = 20;

  /// سماكة الحدود الواضحة.
  static const double borderWidth = 1.5;

  static ThemeData light() => _build(Brightness.light, AppPalette.light);
  static ThemeData dark() => _build(Brightness.dark, AppPalette.dark);

  static ThemeData _build(Brightness brightness, AppPalette p) {
    final isLight = brightness == Brightness.light;

    final scheme = ColorScheme(
      brightness: brightness,
      primary: p.primary,
      onPrimary: p.onPrimary,
      secondary: p.gold,
      onSecondary: p.onPrimary,
      error: p.error,
      onError: isLight ? Colors.white : p.onPrimary,
      surface: p.surface,
      onSurface: p.text,
      outline: p.border,
    );

    // الخط: Cairo، وإن لم يتوفر يُستخدم IBM Plex Sans Arabic.
    final baseText = ThemeData(brightness: brightness, useMaterial3: true).textTheme;
    final fallback = <String>[GoogleFonts.ibmPlexSansArabic().fontFamily!];
    final cairo = GoogleFonts.cairoTextTheme(baseText).apply(
      bodyColor: p.text,
      displayColor: p.text,
      fontFamilyFallback: fallback,
    );

    TextStyle? tune(TextStyle? style, {FontWeight? weight}) =>
        style?.copyWith(height: 1.55, fontWeight: weight);

    final text = cairo.copyWith(
      headlineSmall: tune(cairo.headlineSmall, weight: FontWeight.w700),
      titleLarge: tune(cairo.titleLarge, weight: FontWeight.w700),
      titleMedium: tune(cairo.titleMedium, weight: FontWeight.w700),
      titleSmall: tune(cairo.titleSmall, weight: FontWeight.w600),
      bodyLarge: tune(cairo.bodyLarge),
      bodyMedium: tune(cairo.bodyMedium),
      bodySmall: tune(cairo.bodySmall),
      labelLarge: tune(cairo.labelLarge, weight: FontWeight.w700),
      labelMedium: tune(cairo.labelMedium, weight: FontWeight.w600),
      labelSmall: tune(cairo.labelSmall, weight: FontWeight.w600),
    );

    final roundedShape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(radius),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: p.background,
      textTheme: text,
      primaryTextTheme: text,
      extensions: <ThemeExtension<dynamic>>[p],
      dividerColor: p.border,
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: p.primaryDeep,
        selectionColor: p.primary.withAlpha(90),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: p.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        height: 70,
        indicatorColor: p.primary.withAlpha(isLight ? 70 : 60),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return IconThemeData(
            size: 26,
            color: selected ? p.primaryDeep : p.textMuted,
          );
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return text.labelMedium!.copyWith(
            color: selected ? p.primaryDeep : p.textMuted,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
          );
        }),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: p.primary,
          foregroundColor: p.onPrimary,
          minimumSize: const Size(0, 52),
          shape: roundedShape,
          textStyle: text.labelLarge,
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: p.surface,
        contentTextStyle: text.bodyMedium,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radius),
          side: BorderSide(color: p.border, width: borderWidth),
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: p.surface,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(radius)),
        ),
      ),
    );
  }
}
