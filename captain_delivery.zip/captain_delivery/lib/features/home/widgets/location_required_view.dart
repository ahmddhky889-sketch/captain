import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/app_card.dart';
import '../../../services/location_service.dart';

/// تظهر عند رفض إذن الموقع: "يجب منح إذن الموقع".
class LocationRequiredView extends StatelessWidget {
  const LocationRequiredView({
    super.key,
    required this.status,
    required this.onRetry,
  });

  final LocationStatus status;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;

    final String reason;
    final String buttonLabel;
    final VoidCallback onPressed;
    switch (status) {
      case LocationStatus.deniedForever:
        reason = AppStrings.locationWhyForever;
        buttonLabel = AppStrings.locationOpenSettings;
        onPressed = () => Geolocator.openAppSettings();
      case LocationStatus.serviceOff:
        reason = AppStrings.locationServiceOff;
        buttonLabel = AppStrings.locationOpenSettings;
        onPressed = () => Geolocator.openLocationSettings();
      case LocationStatus.denied:
      case LocationStatus.checking:
      case LocationStatus.granted:
        reason = AppStrings.locationWhyDenied;
        buttonLabel = AppStrings.locationGrant;
        onPressed = onRetry;
    }

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: AppCard(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Icon(Icons.location_on_outlined, size: 48, color: p.primaryDeep),
              const SizedBox(height: 12),
              Text(
                AppStrings.locationRequired,
                style: t.titleLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                reason,
                style: t.bodyMedium?.copyWith(color: p.textMuted),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              FilledButton(onPressed: onPressed, child: Text(buttonLabel)),
            ],
          ),
        ),
      ),
    );
  }
}
