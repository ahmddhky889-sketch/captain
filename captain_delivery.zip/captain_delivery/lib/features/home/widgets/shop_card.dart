import 'package:flutter/material.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/arabic_digits.dart';
import '../../../core/widgets/app_card.dart';
import '../../../data/models/shop.dart';
import '../../../services/delivery_estimator.dart';

/// كرت محل واحد: الأيقونة والاسم والمسافة ووقت التوصيل المتوقع.
class ShopCard extends StatelessWidget {
  const ShopCard({
    super.key,
    required this.shop,
    this.lat,
    this.lng,
    this.onTap,
  });

  final Shop shop;

  /// موقع المستخدم الحالي، لحساب المسافة ووقت التوصيل.
  final double? lat;
  final double? lng;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;

    String? distanceText;
    String? etaText;
    final userLat = lat;
    final userLng = lng;
    if (userLat != null && userLng != null && shop.hasLocation) {
      final km = DeliveryEstimator.distanceKm(
        userLat,
        userLng,
        shop.latitude!,
        shop.longitude!,
      );
      distanceText = formatDistanceAr(km);
      etaText = AppStrings.eta(DeliveryEstimator.minutes(km));
    }

    final subtitle = distanceText == null
        ? shop.category.singular
        : '${shop.category.singular} · $distanceText';

    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: p.primary.withAlpha(40),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(shop.category.icon, size: 28, color: p.primaryDeep),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  shop.name,
                  style: t.titleMedium,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  subtitle,
                  style: t.bodySmall?.copyWith(color: p.textMuted),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (etaText != null) ...[
            const SizedBox(width: 8),
            _EtaPill(text: etaText),
          ],
        ],
      ),
    );
  }
}

class _EtaPill extends StatelessWidget {
  const _EtaPill({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: p.gold.withAlpha(36),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: p.gold.withAlpha(140)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.schedule, size: 16, color: p.goldText),
          const SizedBox(width: 4),
          Text(text, style: t.labelMedium?.copyWith(color: p.goldText)),
        ],
      ),
    );
  }
}
