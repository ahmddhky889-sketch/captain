import 'package:flutter/material.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/sea_pattern.dart';

/// الجملة التشجيعية في آخر الشاشة الرئيسية.
class CaptainFooter extends StatelessWidget {
  const CaptainFooter({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;
    final line = Container(
      width: 40,
      height: 1.5,
      color: p.gold.withAlpha(160),
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              line,
              const SizedBox(width: 12),
              WheelMark(size: 30, color: p.gold),
              const SizedBox(width: 12),
              line,
            ],
          ),
          const SizedBox(height: 12),
          Text(
            AppStrings.footerTagline,
            textAlign: TextAlign.center,
            style: t.titleMedium?.copyWith(color: p.primaryDeep),
          ),
        ],
      ),
    );
  }
}
