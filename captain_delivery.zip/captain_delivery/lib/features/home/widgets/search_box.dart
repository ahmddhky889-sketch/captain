import 'package:flutter/material.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/arabic_digits.dart';

/// خانة البحث في أعلى الشاشة الرئيسية.
class SearchBox extends StatelessWidget {
  const SearchBox({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.onChanged,
    required this.onClear,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;

    return ListenableBuilder(
      listenable: focusNode,
      builder: (context, _) {
        return Container(
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(AppTheme.radius),
            border: Border.all(
              color: focusNode.hasFocus ? p.primary : p.border,
              width: AppTheme.borderWidth,
            ),
          ),
          child: TextField(
            controller: controller,
            focusNode: focusNode,
            onChanged: onChanged,
            textInputAction: TextInputAction.search,
            inputFormatters: [EasternDigitsFormatter()],
            style: t.bodyLarge,
            decoration: InputDecoration(
              hintText: AppStrings.searchHint,
              hintStyle: t.bodyLarge?.copyWith(color: p.textMuted),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 16),
              prefixIcon: Icon(Icons.search, color: p.primaryDeep),
              suffixIcon: ValueListenableBuilder<TextEditingValue>(
                valueListenable: controller,
                builder: (context, value, _) {
                  if (value.text.isEmpty) return const SizedBox.shrink();
                  return IconButton(
                    onPressed: onClear,
                    tooltip: AppStrings.clearSearch,
                    icon: Icon(Icons.close, color: p.textMuted),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }
}
