import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/shop.dart';
import '../../data/models/shop_category.dart';
import '../../data/owner_session.dart';
import '../../data/repositories/shop_repository.dart';
import '../../services/location_service.dart';

/// نافذة إضافة محل جديد (للمالك فقط). تُرجع true عند الحفظ.
Future<bool?> showAddShopSheet(BuildContext context) {
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => const _AddShopForm(),
  );
}

class _AddShopForm extends StatefulWidget {
  const _AddShopForm();

  @override
  State<_AddShopForm> createState() => _AddShopFormState();
}

class _AddShopFormState extends State<_AddShopForm> {
  final _name = TextEditingController();
  final _address = TextEditingController();
  ShopCategory _category = ShopCategory.hyper;
  bool _useMyLocation = true;
  bool _saving = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _address.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() => _error = AppStrings.enterShopName);
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });

    final location = LocationService.instance;
    final address = _address.text.trim();
    final shop = Shop(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      category: _category,
      address: address.isEmpty ? null : address,
      latitude: _useMyLocation ? location.lat : null,
      longitude: _useMyLocation ? location.lng : null,
    );

    try {
      await ShopRepository.instance.addShop(shop);
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on NotOwnerException catch (e) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _error = e.message;
      });
    }
  }

  InputDecoration _decoration(AppPalette p, String label) {
    OutlineInputBorder border(Color color) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppTheme.radius),
          borderSide: BorderSide(color: color, width: AppTheme.borderWidth),
        );
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: p.textMuted),
      enabledBorder: border(p.border),
      focusedBorder: border(p.primary),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;
    final hasLocation = LocationService.instance.position != null;

    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        4,
        20,
        20 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(AppStrings.addShop, style: t.titleLarge),
            const SizedBox(height: 16),
            TextField(
              controller: _name,
              textInputAction: TextInputAction.next,
              decoration: _decoration(p, AppStrings.shopName),
            ),
            const SizedBox(height: 16),
            Text(AppStrings.shopCategory, style: t.labelLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in ShopCategory.values)
                  ChoiceChip(
                    label: Text(c.label),
                    selected: _category == c,
                    showCheckmark: false,
                    selectedColor: p.primary,
                    backgroundColor: p.surface,
                    labelStyle: t.labelLarge?.copyWith(
                      color: _category == c ? p.onPrimary : p.text,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppTheme.radius),
                      side: BorderSide(
                        color: _category == c ? p.primary : p.border,
                        width: AppTheme.borderWidth,
                      ),
                    ),
                    onSelected: (_) => setState(() => _category = c),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _address,
              decoration: _decoration(p, AppStrings.shopAddress),
            ),
            if (hasLocation)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: _useMyLocation,
                onChanged: (v) => setState(() => _useMyLocation = v),
                title: Text(AppStrings.shopUseMyLocation, style: t.bodyMedium),
              ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(
                _error!,
                style: t.bodyMedium?.copyWith(color: p.error),
              ),
            ],
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: Text(AppStrings.save),
            ),
          ],
        ),
      ),
    );
  }
}
