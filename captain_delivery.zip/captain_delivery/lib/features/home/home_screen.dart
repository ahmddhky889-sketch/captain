import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/sea_pattern.dart';
import '../../data/models/shop.dart';
import '../../data/models/shop_category.dart';
import '../../data/owner_session.dart';
import '../../data/repositories/shop_repository.dart';
import '../../services/location_service.dart';
import 'add_shop_sheet.dart';
import 'widgets/captain_footer.dart';
import 'widgets/category_strip.dart';
import 'widgets/location_required_view.dart';
import 'widgets/search_box.dart';
import 'widgets/shop_card.dart';

/// الشاشة الرئيسية: بحث، شريط أقسام، قائمة المحلات، وجملة تشجيعية في الآخر.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final _search = TextEditingController();
  final _focus = FocusNode();
  Timer? _debounce;
  String _query = '';
  ShopCategory _category = ShopCategory.hyper;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounce?.cancel();
    _search.dispose();
    _focus.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // عند العودة من إعدادات الهاتف نفحص الإذن بهدوء.
    final location = LocationService.instance;
    if (state == AppLifecycleState.resumed &&
        location.status != LocationStatus.granted) {
      location.refresh();
    }
  }

  void _onQueryChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 180), () {
      if (mounted) setState(() => _query = value);
    });
  }

  void _clearSearch() {
    _debounce?.cancel();
    _search.clear();
    _focus.unfocus();
    setState(() => _query = '');
  }

  void _openShop(Shop shop) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text(AppStrings.shopSectionsSoon)),
    );
  }

  Future<void> _addShop() async {
    final added = await showAddShopSheet(context);
    if (added == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text(AppStrings.shopAdded)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SeaBackground(
      child: SafeArea(
        child: ListenableBuilder(
          listenable: Listenable.merge([
            LocationService.instance,
            ShopRepository.instance,
            OwnerSession.instance,
          ]),
          builder: (context, _) {
            final location = LocationService.instance;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _Header(
                  showAdd: OwnerSession.instance.isOwner,
                  onAddShop: _addShop,
                ),
                Expanded(child: _body(location)),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _body(LocationService location) {
    switch (location.status) {
      case LocationStatus.checking:
        return const _CheckingLocation();
      case LocationStatus.granted:
        return _content(location);
      case LocationStatus.denied:
      case LocationStatus.deniedForever:
      case LocationStatus.serviceOff:
        return LocationRequiredView(
          status: location.status,
          onRetry: location.retry,
        );
    }
  }

  Widget _content(LocationService location) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: SearchBox(
            controller: _search,
            focusNode: _focus,
            onChanged: _onQueryChanged,
            onClear: _clearSearch,
          ),
        ),
        Expanded(
          child: _query.trim().isEmpty
              ? _categoryView(location)
              : _searchView(location),
        ),
      ],
    );
  }

  Widget _categoryView(LocationService location) {
    final shops = ShopRepository.instance.inCategory(
      _category,
      lat: location.lat,
      lng: location.lng,
    );

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: CategoryStrip(
            selected: _category,
            onSelected: (c) => setState(() => _category = c),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 12)),
        if (shops.isEmpty)
          const SliverToBoxAdapter(
            child: _EmptyState(text: AppStrings.emptyCategory),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverList.separated(
              itemCount: shops.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) => ShopCard(
                shop: shops[i],
                lat: location.lat,
                lng: location.lng,
                onTap: () => _openShop(shops[i]),
              ),
            ),
          ),
        // الجملة التشجيعية في آخر الشاشة، وتثبت في القاع إن كانت القائمة قصيرة.
        const SliverFillRemaining(
          hasScrollBody: false,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: CaptainFooter(),
          ),
        ),
      ],
    );
  }

  Widget _searchView(LocationService location) {
    final result = ShopRepository.instance.search(
      _query,
      lat: location.lat,
      lng: location.lng,
    );

    if (result.isEmpty) {
      return ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        children: const [_EmptyState(text: AppStrings.searchNone)],
      );
    }

    Widget cardFor(Shop shop) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: ShopCard(
            shop: shop,
            lat: location.lat,
            lng: location.lng,
            onTap: () => _openShop(shop),
          ),
        );

    return ListView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      children: [
        if (result.matches.isNotEmpty) ...[
          const _SectionTitle(AppStrings.searchMatches),
          for (final shop in result.matches) cardFor(shop),
        ],
        if (result.related.isNotEmpty) ...[
          const _SectionTitle(AppStrings.searchRelated),
          for (final shop in result.related) cardFor(shop),
        ],
      ],
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.showAdd, required this.onAddShop});

  final bool showAdd;
  final VoidCallback onAddShop;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Row(
        children: [
          WheelMark(size: 34, color: p.gold),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(AppStrings.appName, style: t.titleLarge),
                Text(
                  AppStrings.greeting,
                  style: t.bodySmall?.copyWith(color: p.textMuted),
                ),
              ],
            ),
          ),
          if (showAdd)
            IconButton(
              onPressed: onAddShop,
              tooltip: AppStrings.addShop,
              icon: const Icon(Icons.add_business_outlined),
              style: IconButton.styleFrom(
                foregroundColor: p.primaryDeep,
                backgroundColor: p.surface,
                side: BorderSide(color: p.border, width: 1.5),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 10),
      child: Text(text, style: t.titleSmall),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 40),
      child: Column(
        children: [
          Icon(Icons.explore_outlined, size: 44, color: p.primaryDeep),
          const SizedBox(height: 12),
          Text(
            text,
            textAlign: TextAlign.center,
            style: t.bodyMedium?.copyWith(color: p.textMuted),
          ),
        ],
      ),
    );
  }
}

class _CheckingLocation extends StatelessWidget {
  const _CheckingLocation();

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final t = Theme.of(context).textTheme;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircularProgressIndicator(color: p.primary),
          const SizedBox(height: 16),
          Text(
            AppStrings.locationChecking,
            style: t.bodyMedium?.copyWith(color: p.textMuted),
          ),
        ],
      ),
    );
  }
}
