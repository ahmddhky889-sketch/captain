import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/l10n/app_strings.dart';
import '../../data/repositories/shop_repository.dart';
import '../../services/location_service.dart';
import '../account/account_screen.dart';
import '../home/home_screen.dart';
import '../orders/orders_screen.dart';

/// الهيكل الرئيسي: ثلاثة تبويبات سفلية (حسابي، طلباتي، الرئيسية)
/// مرتبة من اليمين إلى اليسار.
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  // الرئيسية هي الأخيرة في القائمة (أقصى اليسار)، وهي الشاشة الافتراضية.
  int _index = 2;

  @override
  void initState() {
    super.initState();
    LocationService.instance.addListener(_onLocationChanged);
    // أول ما يفتح التطبيق نطلب إذن الموقع.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      LocationService.instance.requestAtLaunch();
    });
  }

  @override
  void dispose() {
    LocationService.instance.removeListener(_onLocationChanged);
    super.dispose();
  }

  void _onLocationChanged() {
    final location = LocationService.instance;
    if (location.status == LocationStatus.granted) {
      ShopRepository.instance.seedDemo(lat: location.lat, lng: location.lng);
    }
  }

  @override
  Widget build(BuildContext context) {
    final darkMode = Theme.of(context).brightness == Brightness.dark;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: darkMode ? Brightness.light : Brightness.dark,
        statusBarBrightness: darkMode ? Brightness.dark : Brightness.light,
      ),
      child: Scaffold(
        body: IndexedStack(
          index: _index,
          children: const [
            AccountScreen(),
            OrdersScreen(),
            HomeScreen(),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: AppStrings.tabAccount,
            ),
            NavigationDestination(
              icon: Icon(Icons.receipt_long_outlined),
              selectedIcon: Icon(Icons.receipt_long),
              label: AppStrings.tabOrders,
            ),
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: AppStrings.tabHome,
            ),
          ],
        ),
      ),
    );
  }
}
