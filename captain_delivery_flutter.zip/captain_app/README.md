# دليفري القبطان (Flutter + Supabase)

الشاشة الرئيسية كاملة بنظام التصميم، وقاعدة البيانات بصلاحية الكتابة للمالك فقط.

> مهم: هذا الكود كُتب دون تشغيله على Flutter، فأول `flutter run` عندك هو أول اختبار حقيقي له.
> لو ظهر أي خطأ، انسخه وأرسله وسأصلحه.

## ما بداخل الحزمة

| المسار | الوظيفة |
|---|---|
| `lib/core/theme.dart` | الألوان (فاتح وداكن) والخط Cairo وبديله IBM Plex Sans Arabic، ونصف قطر الحواف ٢٠ |
| `lib/core/ar_numbers.dart` | تحويل كل رقم إلى الأرقام الشرقية (١٢٣) |
| `lib/core/pattern.dart` | النقشة الهندسية (نجمة البوصلة) |
| `lib/core/icons.dart` | الأيقونات الخطية (بدون أي إيموجي) |
| `lib/core/search.dart` | البحث العربي: مطابقة واقتراحات قريبة |
| `lib/data/` | النماذج، قراءة Supabase، وخدمة الموقع |
| `lib/features/home/` | الشاشة الرئيسية وعناصرها |
| `supabase/schema.sql` | الجداول، الصلاحيات، دالة الأماكن القريبة، تخزين الصور، وأنواع المحلات |

## خطوات التشغيل

### ١) تجهيز Supabase
1. أنشئ مشروعًا في supabase.com.
2. افتح SQL Editor، والصق محتوى `supabase/schema.sql` كاملًا، ثم Run.
3. من Project Settings > API انسخ `Project URL` و `anon public key`.

### ٢) تجهيز مشروع Flutter
```bash
flutter create captain_delivery
```
ثم انسخ من هذه الحزمة فوق المشروع الجديد: مجلد `lib` وملف `pubspec.yaml` (استبدل الموجود).
```bash
cd captain_delivery
flutter pub get
```

### ٣) أذونات الموقع
**أندرويد:** في `android/app/src/main/AndroidManifest.xml` أضف داخل `<manifest>`:
```xml
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
```
**آيفون:** في `ios/Runner/Info.plist` أضف:
```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>نستخدم موقعك لنعرض لك الأماكن الأقرب إليك ونقدّر وقت وصول طلبك.</string>
```

### ٤) التشغيل
```bash
flutter run \
  --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=ضع-المفتاح-هنا
```

### ٥) تعيينك مالكًا
المحلات والأقسام والمنتجات لا يكتبها إلا حسابك. بعد أن يكون عندك حساب في Supabase (Authentication > Users > Add user)، شغّل في SQL Editor:
```sql
insert into public.admins (user_id)
select id from auth.users where email = 'بريدك@example.com';
```
أي حساب آخر لن يستطيع الكتابة، حتى لو حاول مباشرة على قاعدة البيانات.

### إضافة محل تجريبي (من SQL Editor مؤقتًا، لحين بناء لوحة المالك)
```sql
insert into public.places (category_id, name, lat, lng, whatsapp, prep_minutes)
select id, 'اسم المحل', 30.0444, 31.2357, '+201000000000', 15
from public.categories where slug = 'hyper';
```

## ما تم وما لم يتم

**تم:** الشاشة الرئيسية (البحث، إذن الموقع، شريط الأقسام، الكروت، الرسائل التشجيعية، الجملة الختامية، التبويبات الأربعة).

**الخطوة التالية:** شاشة أقسام المحل، ثم شاشة المنتج (الصورة والمميزات والسعر ووقت التوصيل والواتس)، ثم لوحة المالك، ثم التبويبات الأخرى.

## ملاحظات
- الخط يُحمَّل من الإنترنت في أول تشغيل. لتشغيله دون إنترنت نضمّن ملفات الخط داخل التطبيق لاحقًا.
- وقت التوصيل تقدير بسيط: زمن تجهيز المحل + ٣ دقائق لكل كيلومتر + هامش خمس دقائق.
