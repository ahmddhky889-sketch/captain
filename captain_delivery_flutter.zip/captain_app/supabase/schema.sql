-- دليفري القبطان: مخطط قاعدة البيانات
-- الصق هذا الملف كاملًا في Supabase: SQL Editor ثم Run.
--
-- القاعدة الأساسية: الجميع يقرأ، ولا أحد يكتب إلا المالك (الموجود في جدول admins).
-- هذا التحقق يتم داخل قاعدة البيانات نفسها، فلا يمكن تجاوزه من التطبيق أو من أي أداة.

-- ============================================================
-- ١) المالك
-- ============================================================
create table if not exists public.admins (
  user_id uuid primary key references auth.users (id) on delete cascade
);
alter table public.admins enable row level security;
-- لا توجد سياسات على هذا الجدول عمدًا: لا أحد يقرؤه أو يكتب فيه من التطبيق.

create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

-- ============================================================
-- ٢) الجداول
-- ============================================================
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  label text not null,
  icon_key text not null,
  sort_order int not null
);

create table if not exists public.places (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories (id) on delete restrict,
  name text not null,
  lat double precision not null,
  lng double precision not null,
  whatsapp text,                          -- رقم الواتس الخاص بالمحل، تكتبه أنت فقط
  prep_minutes int not null default 15,   -- زمن التجهيز المعتاد، يدخل في تقدير وقت التوصيل
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists places_category_idx on public.places (category_id);

create table if not exists public.sections (
  id uuid primary key default gen_random_uuid(),
  place_id uuid not null references public.places (id) on delete cascade,
  name text not null,
  sort_order int not null default 0
);
create index if not exists sections_place_idx on public.sections (place_id);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references public.sections (id) on delete cascade,
  name text not null,
  image_path text,                        -- مسار الصورة داخل bucket اسمه product-images
  features text,                          -- مميزات المنتج
  price numeric(10, 2),                   -- السعر، تكتبه أنت فقط
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists products_section_idx on public.products (section_id);

-- ============================================================
-- ٣) الصلاحيات (RLS)
-- ============================================================
alter table public.categories enable row level security;
alter table public.places enable row level security;
alter table public.sections enable row level security;
alter table public.products enable row level security;

-- قراءة: متاحة للجميع
drop policy if exists "categories read" on public.categories;
create policy "categories read" on public.categories
  for select to anon, authenticated using (true);

drop policy if exists "places read" on public.places;
create policy "places read" on public.places
  for select to anon, authenticated using (is_active or public.is_admin());

drop policy if exists "sections read" on public.sections;
create policy "sections read" on public.sections
  for select to anon, authenticated using (true);

drop policy if exists "products read" on public.products;
create policy "products read" on public.products
  for select to anon, authenticated using (is_active or public.is_admin());

-- كتابة (إضافة وتعديل وحذف): للمالك فقط
drop policy if exists "categories admin write" on public.categories;
create policy "categories admin write" on public.categories
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "places admin write" on public.places;
create policy "places admin write" on public.places
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "sections admin write" on public.sections;
create policy "sections admin write" on public.sections
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "products admin write" on public.products;
create policy "products admin write" on public.products
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ============================================================
-- ٤) الأماكن القريبة من المستخدم، مرتبة من الأقرب
-- ============================================================
create or replace function public.places_near(p_lat double precision, p_lng double precision)
returns table (
  id uuid,
  category_id uuid,
  name text,
  prep_minutes int,
  distance_km double precision,
  section_names text[]
)
language sql
stable
security invoker
set search_path = public
as $$
  select
    p.id,
    p.category_id,
    p.name,
    p.prep_minutes,
    2 * 6371 * asin(least(1.0, sqrt(
      power(sin(radians(p.lat - p_lat) / 2), 2) +
      cos(radians(p_lat)) * cos(radians(p.lat)) *
      power(sin(radians(p.lng - p_lng) / 2), 2)
    ))) as distance_km,
    coalesce(
      array(
        select s.name from public.sections s
        where s.place_id = p.id
        order by s.sort_order, s.name
        limit 4
      ),
      '{}'::text[]
    ) as section_names
  from public.places p
  where p.is_active
  order by distance_km;
$$;

-- ============================================================
-- ٥) صور المنتجات: القراءة للجميع، والرفع والحذف للمالك فقط
-- ============================================================
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

drop policy if exists "product images read" on storage.objects;
create policy "product images read" on storage.objects
  for select using (bucket_id = 'product-images');

drop policy if exists "product images admin insert" on storage.objects;
create policy "product images admin insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'product-images' and public.is_admin());

drop policy if exists "product images admin update" on storage.objects;
create policy "product images admin update" on storage.objects
  for update to authenticated
  using (bucket_id = 'product-images' and public.is_admin());

drop policy if exists "product images admin delete" on storage.objects;
create policy "product images admin delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'product-images' and public.is_admin());

-- ============================================================
-- ٦) أنواع المحلات بالترتيب المطلوب
-- ============================================================
insert into public.categories (slug, label, icon_key, sort_order) values
  ('hyper',     'الهايبرات',         'hyper', 1),
  ('restaurant','المطاعم',           'rest',  2),
  ('cafe',      'المقاهي',           'cafe',  3),
  ('vegetables','محلات الخضروات',    'veg',   4),
  ('fruits',    'محلات الفواكه',     'fruit', 5),
  ('drinks',    'محلات المشروبات',   'drink', 6),
  ('sweets',    'محلات الحلويات',    'sweet', 7),
  ('clothes',   'محلات الملابس',     'cloth', 8),
  ('pharmacy',  'الصيدليات',         'pharm', 9),
  ('bakery',    'المخابز',           'bread', 10),
  ('meat',      'اللحوم والدواجن',   'meat',  11),
  ('spices',    'العطارة',           'spice', 12),
  ('books',     'المكتبات والأدوات', 'book',  13)
on conflict (slug) do nothing;

-- ============================================================
-- ٧) تعيينك مالكًا (نفّذ هذا بعد أن تسجّل دخولك أول مرة في التطبيق)
-- ============================================================
-- استبدل البريد ببريدك الذي سجّلت به، ثم شغّل السطر:
--
-- insert into public.admins (user_id)
-- select id from auth.users where email = 'ضع-بريدك-هنا@example.com';
