import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/theme.dart';
import 'features/home/home_screen.dart';

// تُمرَّر عند التشغيل:
// flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final configured = _supabaseUrl.isNotEmpty && _supabaseAnonKey.isNotEmpty;
  if (configured) {
    await Supabase.initialize(url: _supabaseUrl, anonKey: _supabaseAnonKey);
  }
  runApp(CaptainApp(configured: configured));
}

class CaptainApp extends StatelessWidget {
  const CaptainApp({super.key, required this.configured});

  final bool configured;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'دليفري القبطان',
      debugShowCheckedModeBanner: false,
      // الألوان فاتحة وداكنة وتتبع إعداد النظام تلقائيًا.
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      // عربي بالكامل ومن اليمين إلى اليسار.
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: configured ? const HomeScreen() : const _MissingConfig(),
    );
  }
}

class _MissingConfig extends StatelessWidget {
  const _MissingConfig();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'أضف بيانات Supabase عند التشغيل (SUPABASE_URL و SUPABASE_ANON_KEY) كما في ملف README.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
