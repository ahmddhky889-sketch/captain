import 'dart:async';
import 'package:flutter/material.dart';

import '../../core/ar_numbers.dart';
import '../../core/icons.dart';
import '../../core/pattern.dart';
import '../../core/search.dart';
import '../../core/theme.dart';
import '../../data/location_service.dart';
import '../../data/models.dart';

/// شريط أنواع المحلات: يبدأ من اليمين ويتحرك أفقيًا.
class CategoryStrip extends StatelessWidget {
  const CategoryStrip({
    super.key,
    required this.categories,
    required this.selected,
    required this.onSelect,
  });

  final List<Category> categories;
  final int selected;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return SizedBox(
      height: 118,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final cat = categories[i];
          final on = i == selected;
          return Semantics(
            button: true,
            selected: on,
            label: cat.label,
            child: InkWell(
              borderRadius: BorderRadius.circular(kRadius),
              onTap: () => onSelect(i),
              child: SizedBox(
                width: 78,
                child: Column(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: on ? c.primary : c.surface,
                        borderRadius: BorderRadius.circular(kRadius),
                        border: Border.all(color: on ? c.primary : c.line, width: 1.5),
                      ),
                      child: CaptainIcon(cat.iconKey, color: on ? c.onPrimary : c.primary),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      width: 18,
                      height: 4,
                      decoration: BoxDecoration(
                        color: on ? c.gold : Colors.transparent,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      cat.label,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        height: 1.35,
                        fontWeight: on ? FontWeight.w800 : FontWeight.w600,
                        color: on ? c.primary : c.fg,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.text, this.gold = false});
  final String icon;
  final String text;
  final bool gold;

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final ink = gold ? c.goldInk : c.fg;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      decoration: BoxDecoration(
        color: gold ? c.goldSoft : c.surface2,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CaptainIcon(icon, size: 14, color: ink),
          const SizedBox(width: 4),
          Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: ink)),
        ],
      ),
    );
  }
}

/// كارت المكان: الاسم، الأقسام، المسافة، ووقت التوصيل التقريبي.
class PlaceCard extends StatelessWidget {
  const PlaceCard({
    super.key,
    required this.place,
    required this.iconKey,
    required this.onTap,
    this.flash = false,
  });

  final Place place;
  final String iconKey;
  final VoidCallback onTap;
  final bool flash;

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Material(
      color: c.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kRadius),
        side: BorderSide(color: flash ? c.gold : c.line, width: 1.5),
      ),
      child: InkWell(
        customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kRadius)),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  width: 76,
                  height: 76,
                  color: c.primarySoft,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CaptainPattern(color: c.pattern),
                      CaptainIcon(iconKey, size: 32, color: c.primary),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      place.name,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, height: 1.3),
                    ),
                    if (place.sections.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        'الأقسام: ${place.sectionsText}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, color: c.fg2),
                      ),
                    ],
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        _Pill(icon: 'pin', text: arKm(place.distanceKm)),
                        _Pill(icon: 'clock', text: place.etaText, gold: true),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// نتائج البحث: مطابقة أولًا، ثم اقتراحات قريبة.
class SearchPanel extends StatelessWidget {
  const SearchPanel({
    super.key,
    required this.result,
    required this.categoryOf,
    required this.onPick,
  });

  final SearchResult result;
  final Category? Function(String categoryId) categoryOf;
  final ValueChanged<Place> onPick;

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final rows = <Widget>[];

    void header(String text) => rows.add(Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
          child: Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: c.fg2)),
        ));

    Widget tile(Place p) {
      final cat = categoryOf(p.categoryId);
      return InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => onPick(p),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: c.primarySoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: CaptainIcon(cat?.iconKey ?? 'pin', size: 22, color: c.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, height: 1.3)),
                    Text(
                      '${cat?.label ?? ''} - ${arKm(p.distanceKm)}',
                      style: TextStyle(fontSize: 12, color: c.fg2),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (result.exact.isNotEmpty) {
      header('نتائج مطابقة');
      rows.addAll(result.exact.map(tile));
    }
    if (result.near.isNotEmpty) {
      header('اقتراحات قريبة');
      rows.addAll(result.near.map(tile));
    }
    if (result.isEmpty) {
      rows.add(Padding(
        padding: const EdgeInsets.all(12),
        child: Text(
          'لم نجد مطابقًا الآن، جرّب كلمة أخرى أو اختر نوع المحل من الشريط.',
          style: TextStyle(fontSize: 13, color: c.fg2),
        ),
      ));
    }

    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: c.surface,
        borderRadius: BorderRadius.circular(kRadius),
        border: Border.all(color: c.line, width: 1.5),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: rows),
    );
  }
}

/// رسائل تشجيعية هادئة تتبدّل كل فترة داخل التطبيق.
class NoteStrip extends StatefulWidget {
  const NoteStrip({super.key});

  @override
  State<NoteStrip> createState() => _NoteStripState();
}

class _NoteStripState extends State<NoteStrip> {
  static const _messages = [
    'ادخل على دليفري القبطان الآن، ستجد ما يسرّك',
    'نوصّل إليك ما تحتاجه بهدوء وأمان',
    'اختر ما يناسبك، ونحن نتكفّل بالباقي',
    'يسعدنا أن نخدمك اليوم',
  ];
  int _i = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 9), (_) {
      if (mounted) setState(() => _i = (_i + 1) % _messages.length);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final calm = MediaQuery.of(context).disableAnimations;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: c.goldSoft,
        borderRadius: BorderRadius.circular(kRadius),
      ),
      child: AnimatedSwitcher(
        duration: calm ? Duration.zero : const Duration(milliseconds: 300),
        child: Text(
          _messages[_i],
          key: ValueKey(_i),
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: c.goldInk),
        ),
      ),
    );
  }
}

/// الجملة التشجيعية في آخر الشاشة الرئيسية.
class CheerCard extends StatelessWidget {
  const CheerCard({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 26),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: c.goldSoft,
        borderRadius: BorderRadius.circular(kRadius),
        border: Border.all(color: c.gold, width: 1.5),
      ),
      child: Stack(
        children: [
          CaptainPattern(color: c.pattern, opacity: .5),
          Column(
            children: [
              Text(
                'قُبْطَانُكَ دَلِيلُكَ لِبَرِّ الأَمَانِ',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22, height: 1.9, fontWeight: FontWeight.w800, color: c.goldInk),
              ),
              const SizedBox(height: 6),
              Text(
                'اطلب ما يسرّك الآن، ونوصّله إليك بهدوء وأمان.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: c.goldInk),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// حالة عدم منح إذن الموقع.
class DeniedCard extends StatelessWidget {
  const DeniedCard({super.key, required this.status, required this.onPressed});

  final LocationStatus status;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final serviceOff = status == LocationStatus.serviceOff;
    final title = serviceOff ? 'يجب تشغيل خدمة الموقع' : 'يجب منح إذن الموقع';
    final body = serviceOff
        ? 'شغّل خدمة الموقع في جهازك لنعرض لك الأماكن الأقرب إليك ونقدّر وقت وصول طلبك.'
        : 'نحتاج موقعك لنعرض لك الأماكن الأقرب إليك ونقدّر وقت وصول طلبك. يمكنك تفعيله من إعدادات الجهاز في أي وقت.';
    final button = status == LocationStatus.denied ? 'منح الإذن' : 'فتح الإعدادات';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: c.surface,
        borderRadius: BorderRadius.circular(kRadius),
        border: Border.all(color: c.line, width: 1.5),
      ),
      child: Stack(
        children: [
          CaptainPattern(color: c.pattern, opacity: .5),
          SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: c.goldSoft,
                    borderRadius: BorderRadius.circular(kRadius),
                  ),
                  child: CaptainIcon('pinoff', size: 32, color: c.goldInk),
                ),
                const SizedBox(height: 12),
                Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(body, textAlign: TextAlign.center, style: TextStyle(color: c.fg2, height: 1.6)),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: onPressed,
                  style: FilledButton.styleFrom(
                    backgroundColor: c.primary,
                    foregroundColor: c.onPrimary,
                    minimumSize: const Size(0, 48),
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kRadius)),
                    textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  child: Text(button),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// التبويبات الأربعة بالترتيب من اليمين: حسابي، طلباتي، الرئيسية، التواصل مع محبين آخرين.
class CaptainTabBar extends StatelessWidget {
  const CaptainTabBar({super.key, required this.onOther});

  final ValueChanged<String> onOther;

  static const _items = [
    ('user', 'حسابي'),
    ('bag', 'طلباتي'),
    ('home', 'الرئيسية'),
    ('heart', 'التواصل مع محبين آخرين'),
  ];

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Container(
      decoration: BoxDecoration(
        color: c.surface,
        border: Border(top: BorderSide(color: c.line, width: 1.5)),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(kRadius)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final item in _items)
                Expanded(
                  child: _Tab(
                    icon: item.$1,
                    label: item.$2,
                    selected: item.$2 == 'الرئيسية',
                    onTap: () => onOther(item.$2),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  const _Tab({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final ink = selected ? c.primary : c.fg2;
    return Semantics(
      button: true,
      selected: selected,
      label: label,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: selected ? null : onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
          decoration: BoxDecoration(
            color: selected ? c.primarySoft : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            children: [
              CaptainIcon(icon, color: ink),
              const SizedBox(height: 3),
              Text(
                label,
                textAlign: TextAlign.center,
                maxLines: 2,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.25,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  color: ink,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
