import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/ar_numbers.dart';
import '../../core/icons.dart';
import '../../core/pattern.dart';
import '../../core/search.dart';
import '../../core/theme.dart';
import '../../data/location_service.dart';
import '../../data/models.dart';
import '../../data/repository.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final _repo = CaptainRepository(Supabase.instance.client);
  final _query = TextEditingController();
  final _scroll = ScrollController();
  final _keys = <String, GlobalKey>{};

  LocationStatus? _status; // null = جاري الطلب
  double? _lat;
  double? _lng;

  List<Category> _cats = [];
  List<Place> _places = [];
  int _catIndex = 0;
  bool _loading = false;
  String? _error;

  bool _panelOpen = false;
  String? _flashId;
  Timer? _flashTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // يُطلب إذن الموقع مباشرة عند فتح التطبيق.
    WidgetsBinding.instance.addPostFrameCallback((_) => _askLocation());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _flashTimer?.cancel();
    _query.dispose();
    _scroll.dispose();
    super.dispose();
  }

  /// عند العودة من إعدادات الجهاز نعيد التحقق تلقائيًا.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed &&
        (_status == LocationStatus.deniedForever || _status == LocationStatus.serviceOff)) {
      _askLocation();
    }
  }

  Future<void> _askLocation() async {
    setState(() => _status = null);
    LocationResult result;
    try {
      result = await LocationService.request();
    } catch (_) {
      result = const LocationResult(LocationStatus.denied);
    }
    if (!mounted) return;
    setState(() {
      _status = result.status;
      _lat = result.position?.latitude;
      _lng = result.position?.longitude;
    });
    if (result.status == LocationStatus.granted) await _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait<Object>([
        _repo.categories(),
        _repo.placesNear(_lat!, _lng!),
      ]);
      if (!mounted) return;
      setState(() {
        _cats = results[0] as List<Category>;
        _places = results[1] as List<Place>;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'تعذّر تحميل الأماكن الآن، جرّب مرة أخرى بعد قليل.';
      });
    }
  }

  void _toast(String message) {
    final c = context.c;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(message, textAlign: TextAlign.center),
        behavior: SnackBarBehavior.floating,
        backgroundColor: c.fg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kRadius)),
      ));
  }

  Category? _categoryOf(String id) {
    for (final c in _cats) {
      if (c.id == id) return c;
    }
    return null;
  }

  void _pick(Place place) {
    final index = _cats.indexWhere((c) => c.id == place.categoryId);
    FocusScope.of(context).unfocus();
    setState(() {
      if (index >= 0) _catIndex = index;
      _panelOpen = false;
      _query.text = place.name;
      _flashId = place.id;
    });
    _flashTimer?.cancel();
    _flashTimer = Timer(const Duration(milliseconds: 2200), () {
      if (mounted) setState(() => _flashId = null);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _keys[place.id]?.currentContext;
      if (ctx != null) {
        Scrollable.ensureVisible(ctx, alignment: .4, duration: const Duration(milliseconds: 350));
      }
    });
  }

  void _onDeniedPressed() {
    final status = _status;
    if (status == null) return;
    if (status == LocationStatus.denied) {
      _askLocation();
    } else {
      LocationService.openSettings(status);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Scaffold(
      backgroundColor: c.bg,
      bottomNavigationBar: CaptainTabBar(
        onOther: (_) => _toast('سنجهّز هذه الشاشة معك في الخطوة التالية'),
      ),
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () => FocusScope.of(context).unfocus(),
        child: SingleChildScrollView(
          controller: _scroll,
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _band(context),
              ..._body(context),
            ],
          ),
        ),
      ),
    );
  }

  /// الهيدر: خانة البحث في الأعلى، ثم سطر الموقع واسم التطبيق.
  Widget _band(BuildContext context) {
    final c = context.c;
    final granted = _status == LocationStatus.granted;
    final labels = {for (final cat in _cats) cat.id: cat.label};

    return Container(
      clipBehavior: Clip.antiAlias,
      padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 16, 16, 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [c.band1, c.band2],
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(kRadius)),
      ),
      child: Stack(
        children: [
          CaptainPattern(color: c.pattern, opacity: .7),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _query,
                enabled: granted,
                textInputAction: TextInputAction.search,
                style: const TextStyle(fontSize: 15),
                onChanged: (v) => setState(() => _panelOpen = v.trim().isNotEmpty),
                decoration: InputDecoration(
                  hintText: 'ابحث عن مطعم أو هايبر أو مقهى',
                  hintStyle: TextStyle(color: c.fg2, fontSize: 15),
                  filled: true,
                  fillColor: c.surface,
                  contentPadding: const EdgeInsets.symmetric(vertical: 16),
                  prefixIcon: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: CaptainIcon('search', color: c.primary),
                  ),
                  prefixIconConstraints: const BoxConstraints(minWidth: 52),
                  suffixIcon: _query.text.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'مسح البحث',
                          icon: CaptainIcon('x', size: 18, color: c.fg2),
                          onPressed: () => setState(() {
                            _query.clear();
                            _panelOpen = false;
                          }),
                        ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(kRadius),
                    borderSide: BorderSide(color: c.line, width: 1.5),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(kRadius),
                    borderSide: BorderSide(color: c.line, width: 1.5),
                  ),
                  disabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(kRadius),
                    borderSide: BorderSide(color: c.line.withOpacity(.6), width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(kRadius),
                    borderSide: BorderSide(color: c.primary, width: 1.5),
                  ),
                ),
              ),
              if (granted && _panelOpen)
                SearchPanel(
                  result: searchPlaces(_query.text, _places, labels),
                  categoryOf: _categoryOf,
                  onPick: _pick,
                ),
              const SizedBox(height: 12),
              Row(
                children: [
                  CaptainIcon(granted ? 'pin' : 'pinoff', size: 20, color: c.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: granted
                        ? Text.rich(
                            const TextSpan(
                              text: 'التوصيل إلى ',
                              children: [
                                TextSpan(
                                  text: 'موقعك الحالي',
                                  style: TextStyle(fontWeight: FontWeight.w700),
                                ),
                              ],
                            ),
                            style: const TextStyle(fontSize: 13),
                          )
                        : const Text('الموقع غير مفعّل', style: TextStyle(fontSize: 13)),
                  ),
                  CaptainIcon('compass', size: 18, color: c.gold),
                  const SizedBox(width: 6),
                  Text(
                    'دليفري القبطان',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: c.goldInk),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _body(BuildContext context) {
    final c = context.c;
    const gutter = EdgeInsets.symmetric(horizontal: 16);

    if (_status == null) {
      return const [
        Padding(
          padding: EdgeInsets.symmetric(vertical: 64),
          child: Center(child: CircularProgressIndicator()),
        ),
      ];
    }
    if (_status != LocationStatus.granted) {
      return [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
          child: DeniedCard(status: _status!, onPressed: _onDeniedPressed),
        ),
      ];
    }
    if (_loading) {
      return const [
        Padding(
          padding: EdgeInsets.symmetric(vertical: 64),
          child: Center(child: CircularProgressIndicator()),
        ),
      ];
    }
    if (_error != null) {
      return [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 24),
          child: Column(
            children: [
              Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: c.fg2)),
              const SizedBox(height: 12),
              OutlinedButton(onPressed: _load, child: const Text('إعادة المحاولة')),
            ],
          ),
        ),
      ];
    }
    if (_cats.isEmpty) {
      return [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 32, 16, 24),
          child: Text(
            'نجهّز لك الأماكن القريبة، وستجد ما يسرّك هنا قريبًا.',
            textAlign: TextAlign.center,
            style: TextStyle(color: c.fg2),
          ),
        ),
      ];
    }

    final index = _catIndex.clamp(0, _cats.length - 1).toInt();
    final cat = _cats[index];
    final list = _places.where((p) => p.categoryId == cat.id).toList();

    return [
      const Padding(padding: EdgeInsets.fromLTRB(16, 14, 16, 0), child: NoteStrip()),
      const SizedBox(height: 16),
      CategoryStrip(
        categories: _cats,
        selected: index,
        onSelect: (i) => setState(() => _catIndex = i),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(cat.label, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, height: 1.3)),
            Text('${arCount(list.length)} مرتبة من الأقرب', style: TextStyle(fontSize: 12, color: c.fg2)),
          ],
        ),
      ),
      if (list.isEmpty)
        Padding(
          padding: gutter,
          child: Text(
            'لا توجد أماكن في هذا القسم الآن، وسنضيف المزيد قريبًا.',
            style: TextStyle(color: c.fg2),
          ),
        )
      else
        Padding(
          padding: gutter,
          child: Column(
            children: [
              for (final p in list) ...[
                PlaceCard(
                  key: _keys.putIfAbsent(p.id, () => GlobalKey()),
                  place: p,
                  iconKey: cat.iconKey,
                  flash: p.id == _flashId,
                  onTap: () => _toast('ستظهر أقسام ${p.name} في الشاشة التالية'),
                ),
                const SizedBox(height: 12),
              ],
            ],
          ),
        ),
      const Padding(padding: EdgeInsets.fromLTRB(16, 10, 16, 24), child: CheerCard()),
    ];
  }
}
