import 'package:geolocator/geolocator.dart';

enum LocationStatus { granted, denied, deniedForever, serviceOff }

class LocationResult {
  const LocationResult(this.status, [this.position]);
  final LocationStatus status;
  final Position? position;
}

class LocationService {
  /// يطلب إذن الموقع (نافذة النظام) ثم يقرأ الموقع الحالي.
  static Future<LocationResult> request() async {
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.deniedForever) {
      return const LocationResult(LocationStatus.deniedForever);
    }
    if (permission == LocationPermission.denied) {
      return const LocationResult(LocationStatus.denied);
    }
    if (!await Geolocator.isLocationServiceEnabled()) {
      return const LocationResult(LocationStatus.serviceOff);
    }
    final position = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium),
    );
    return LocationResult(LocationStatus.granted, position);
  }

  static Future<void> openSettings(LocationStatus status) async {
    if (status == LocationStatus.serviceOff) {
      await Geolocator.openLocationSettings();
    } else {
      await Geolocator.openAppSettings();
    }
  }
}
