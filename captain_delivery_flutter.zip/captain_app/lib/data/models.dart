import '../core/ar_numbers.dart';

class Category {
  const Category({required this.id, required this.label, required this.iconKey});

  final String id;
  final String label;
  final String iconKey;

  factory Category.fromMap(Map<String, dynamic> m) => Category(
        id: m['id'] as String,
        label: m['label'] as String,
        iconKey: m['icon_key'] as String,
      );
}

class Place {
  const Place({
    required this.id,
    required this.categoryId,
    required this.name,
    required this.prepMinutes,
    required this.distanceKm,
    required this.sections,
  });

  final String id;
  final String categoryId;
  final String name;
  final int prepMinutes;
  final double distanceKm;
  final List<String> sections;

  factory Place.fromMap(Map<String, dynamic> m) => Place(
        id: m['id'] as String,
        categoryId: m['category_id'] as String,
        name: m['name'] as String,
        prepMinutes: (m['prep_minutes'] as num).toInt(),
        distanceKm: (m['distance_km'] as num).toDouble(),
        sections: ((m['section_names'] as List?) ?? const [])
            .map((e) => e.toString())
            .toList(),
      );

  /// تقدير وقت التوصيل: زمن التجهيز + ٣ دقائق لكل كيلومتر، ثم هامش خمس دقائق.
  int get etaLow => prepMinutes + (distanceKm * 3).round();
  int get etaHigh => etaLow + 5;
  String get etaText => 'من ${arNum(etaLow)} إلى ${arNum(etaHigh)} دقيقة';
  String get sectionsText => sections.join('، ');
}
