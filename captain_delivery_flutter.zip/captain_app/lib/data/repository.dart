import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';

/// كل قراءة من قاعدة البيانات تمر من هنا. الكتابة ليست هنا عمدًا:
/// الإضافة والتعديل للمالك فقط وستكون في لوحة المالك لاحقًا.
class CaptainRepository {
  CaptainRepository(this._db);
  final SupabaseClient _db;

  Future<List<Category>> categories() async {
    final rows = await _db.from('categories').select().order('sort_order');
    return rows.map<Category>((m) => Category.fromMap(m)).toList();
  }

  Future<List<Place>> placesNear(double lat, double lng) async {
    final rows = await _db.rpc('places_near', params: {'p_lat': lat, 'p_lng': lng});
    return (rows as List)
        .map<Place>((m) => Place.fromMap(Map<String, dynamic>.from(m as Map)))
        .toList();
  }
}
