import 'dart:math' as math;
import 'package:flutter/material.dart';

/// النقشة الهندسية: نجمة بوصلة ثمانية الرؤوس، تعبّر عن "القبطان".
class CaptainPatternPainter extends CustomPainter {
  CaptainPatternPainter(this.color);
  final Color color;

  static const double _tile = 48;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (double y = 0; y < size.height + _tile; y += _tile) {
      for (double x = 0; x < size.width + _tile; x += _tile) {
        final center = Offset(x + _tile / 2, y + _tile / 2);
        canvas.drawRect(Rect.fromCenter(center: center, width: 28, height: 28), paint);
        canvas.save();
        canvas.translate(center.dx, center.dy);
        canvas.rotate(math.pi / 4);
        canvas.drawRect(Rect.fromCenter(center: Offset.zero, width: 28, height: 28), paint);
        canvas.restore();
        canvas.drawCircle(center, 4, paint);
        canvas.drawCircle(Offset(x, y), 3, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CaptainPatternPainter oldDelegate) => oldDelegate.color != color;
}

/// خلفية نقشة تملأ أبعاد أبيها. ضعها أول عنصر داخل Stack.
class CaptainPattern extends StatelessWidget {
  const CaptainPattern({super.key, required this.color, this.opacity = 1});
  final Color color;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: opacity,
          child: CustomPaint(painter: CaptainPatternPainter(color)),
        ),
      ),
    );
  }
}
