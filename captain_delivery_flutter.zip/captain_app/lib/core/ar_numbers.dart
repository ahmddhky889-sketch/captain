/// تحويل أي رقم إلى الأرقام العربية الشرقية (١٢٣). كل رقم يظهر في التطبيق يمر من هنا.
const String _digits = '٠١٢٣٤٥٦٧٨٩';

String arNum(Object value) {
  final out = StringBuffer();
  for (final rune in value.toString().runes) {
    final ch = String.fromCharCode(rune);
    if (rune >= 0x30 && rune <= 0x39) {
      out.write(_digits[rune - 0x30]);
    } else if (ch == '.') {
      out.write('٫');
    } else {
      out.write(ch);
    }
  }
  return out.toString();
}

String arKm(double km) => '${arNum(km.toStringAsFixed(1))} كم';

String arCount(int n) {
  if (n == 1) return 'مكان واحد';
  if (n == 2) return 'مكانان';
  return '${arNum(n)} أماكن';
}
