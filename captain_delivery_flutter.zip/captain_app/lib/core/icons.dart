import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// أيقونات خطية بنفس رسم النموذج الأول. لا إيموجي في أي مكان.
const Map<String, String> _paths = {
  'hyper': '<path d="M3 4h2l2.2 11h10.6l2-8H6.2"/><circle cx="9" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/>',
  'rest': '<path d="M6 3v5a2 2 0 0 0 4 0V3M8 10v11M18 21V3c-2.2 1.2-3 4-3 7h3"/>',
  'cafe': '<path d="M4 9h12v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V9zM16 10h1.5a2.5 2.5 0 0 1 0 5H16M8 3v3M12 3v3"/>',
  'veg': '<path d="M5 19c0-9 5-14 14-14 0 9-5 14-14 14zM5 19l8-8"/>',
  'fruit': '<path d="M12 7c-2-2-6-1-6 4 0 4 2.5 9 6 9s6-5 6-9c0-5-4-6-6-4zM12 7c0-2 1-3.5 3-4"/>',
  'drink': '<path d="M6 3h12l-1.5 17a1 1 0 0 1-1 1h-7a1 1 0 0 1-1-1L6 3zM7 9h10"/>',
  'sweet': '<path d="M4 20h16M5 20v-6h14v6M6 14c0-2 2-3 3-3s1.5-1 3-1 2 1 3 1 3 1 3 3M12 4v4"/>',
  'cloth': '<path d="M8 4L3 7l2.5 4L8 10v10h8V10l2.5 1L21 7l-5-3c0 1.7-1.8 3-4 3S8 5.7 8 4z"/>',
  'pharm': '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M12 8v8M8 12h8"/>',
  'bread': '<path d="M5 10c0-3 3-5 7-5s7 2 7 5c0 1-.6 1.6-1.5 1.8V19h-11v-7.2C5.6 11.6 5 11 5 10zM10 10l1 2M14 10l1 2"/>',
  'meat': '<circle cx="9" cy="9" r="5"/><path d="M13 13l6 6M17.5 20.5a1.5 1.5 0 1 0 3-3"/>',
  'spice': '<path d="M7 4h10v3H7zM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7zM9 12h6"/>',
  'book': '<path d="M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3V4zM5 17a3 3 0 0 1 3-3h10"/>',
  'user': '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  'bag': '<path d="M5 8h14l-1 12H6L5 8zM9 8V6a3 3 0 0 1 6 0v2"/>',
  'home': '<path d="M4 11l8-7 8 7v9H4zM10 20v-6h4v6"/>',
  'heart': '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/>',
  'search': '<circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/>',
  'pin': '<path d="M12 21s-6-5.5-6-11a6 6 0 0 1 12 0c0 5.5-6 11-6 11z"/><circle cx="12" cy="10" r="2.2"/>',
  'pinoff': '<path d="M12 21s-6-5.5-6-11a6 6 0 0 1 12 0c0 5.5-6 11-6 11z"/><circle cx="12" cy="10" r="2.2"/><path d="M4 4l16 16"/>',
  'clock': '<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>',
  'x': '<path d="M6 6l12 12M18 6L6 18"/>',
  'compass': '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
};

class CaptainIcon extends StatelessWidget {
  const CaptainIcon(this.name, {super.key, this.size = 24, this.color});

  final String name;
  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final tint = color ?? IconTheme.of(context).color ?? const Color(0xFF000000);
    final svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
        'stroke="#000000" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'
        '${_paths[name] ?? ''}</svg>';
    return SvgPicture.string(
      svg,
      width: size,
      height: size,
      colorFilter: ColorFilter.mode(tint, BlendMode.srcIn),
    );
  }
}
