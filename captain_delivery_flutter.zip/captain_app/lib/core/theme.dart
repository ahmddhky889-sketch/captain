import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// نصف قطر الحواف في كل الكروت.
const double kRadius = 20;

/// ألوان "دليفري القبطان": أزرق بلون البحر كأساس، وذهبي للتمييز فقط.
@immutable
class CaptainColors extends ThemeExtension<CaptainColors> {
  const CaptainColors({
    required this.bg,
    required this.surface,
    required this.surface2,
    required this.line,
    required this.fg,
    required this.fg2,
    required this.primary,
    required this.onPrimary,
    required this.primarySoft,
    required this.band1,
    required this.band2,
    required this.gold,
    required this.goldSoft,
    required this.goldInk,
    required this.pattern,
  });

  final Color bg;
  final Color surface;
  final Color surface2;
  final Color line;
  final Color fg;
  final Color fg2;
  final Color primary;
  final Color onPrimary;
  final Color primarySoft;
  final Color band1;
  final Color band2;
  final Color gold;
  final Color goldSoft;
  final Color goldInk;
  final Color pattern;

  static const light = CaptainColors(
    bg: Color(0xFFF4F9FB),
    surface: Color(0xFFFFFFFF),
    surface2: Color(0xFFEAF4F8),
    line: Color(0xFFC9DDE5),
    fg: Color(0xFF10303D),
    fg2: Color(0xFF4B6874),
    primary: Color(0xFF1B7FAE),
    onPrimary: Color(0xFFFFFFFF),
    primarySoft: Color(0xFFD8EEF6),
    band1: Color(0xFFCFEAF5),
    band2: Color(0xFFE3F3F9),
    gold: Color(0xFFC9962B),
    goldSoft: Color(0xFFF7EBCB),
    goldInk: Color(0xFF6B4A06),
    pattern: Color(0x3D1B7FAE),
  );

  static const dark = CaptainColors(
    bg: Color(0xFF0B1B23),
    surface: Color(0xFF122732),
    surface2: Color(0xFF173341),
    line: Color(0xFF27414E),
    fg: Color(0xFFE6F3F8),
    fg2: Color(0xFF9DB8C4),
    primary: Color(0xFF58BFE3),
    onPrimary: Color(0xFF06222D),
    primarySoft: Color(0xFF173B4A),
    band1: Color(0xFF123241),
    band2: Color(0xFF0E2630),
    gold: Color(0xFFE0B04A),
    goldSoft: Color(0xFF3A2F14),
    goldInk: Color(0xFFF0CF85),
    pattern: Color(0x3858BFE3),
  );

  @override
  CaptainColors copyWith() => this;

  @override
  CaptainColors lerp(ThemeExtension<CaptainColors>? other, double t) {
    if (other is! CaptainColors) return this;
    return t < 0.5 ? this : other;
  }
}

extension CaptainContext on BuildContext {
  CaptainColors get c => Theme.of(this).extension<CaptainColors>()!;
}

/// الثيم الفاتح والداكن. الخط Cairo وبديله IBM Plex Sans Arabic.
ThemeData buildTheme(Brightness brightness) {
  final c = brightness == Brightness.light ? CaptainColors.light : CaptainColors.dark;
  final base = ThemeData(
    useMaterial3: true,
    brightness: brightness,
    scaffoldBackgroundColor: c.bg,
    colorScheme: ColorScheme.fromSeed(
      seedColor: c.primary,
      brightness: brightness,
    ).copyWith(
      primary: c.primary,
      onPrimary: c.onPrimary,
      surface: c.surface,
      onSurface: c.fg,
    ),
    extensions: [c],
  );
  final fallback = GoogleFonts.ibmPlexSansArabic().fontFamily;
  return base.copyWith(
    textTheme: GoogleFonts.cairoTextTheme(base.textTheme).apply(
      bodyColor: c.fg,
      displayColor: c.fg,
      fontFamilyFallback: fallback == null ? null : [fallback],
    ),
  );
}
