import '../data/models.dart';

/// توحيد الحروف العربية قبل المقارنة: الهمزات، التاء المربوطة، الياء، التشكيل.
String normalizeAr(String s) {
  var t = s.toLowerCase();
  t = t.replaceAll(RegExp('[ً-ٰٟـ]'), '');
  t = t
      .replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll('ؤ', 'و')
      .replaceAll('ئ', 'ي');
  return t.replaceAll(RegExp(r'\s+'), ' ').trim();
}

List<String> _words(String s) => normalizeAr(s)
    .split(RegExp(r'[\s،,]+'))
    .where((w) => w.isNotEmpty)
    .map((w) => (w.startsWith('ال') && w.length > 2) ? w.substring(2) : w)
    .toList();

int _lev(String a, String b) {
  final m = a.length;
  final n = b.length;
  final d = List.generate(m + 1, (i) => List<int>.filled(n + 1, 0));
  for (var i = 0; i <= m; i++) {
    d[i][0] = i;
  }
  for (var j = 0; j <= n; j++) {
    d[0][j] = j;
  }
  for (var i = 1; i <= m; i++) {
    for (var j = 1; j <= n; j++) {
      final cost = a[i - 1] == b[j - 1] ? 0 : 1;
      final best = [d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost]
          .reduce((x, y) => x < y ? x : y);
      d[i][j] = best;
    }
  }
  return d[m][n];
}

class SearchResult {
  const SearchResult(this.exact, this.near);
  final List<Place> exact;
  final List<Place> near;
  bool get isEmpty => exact.isEmpty && near.isEmpty;
}

/// نتائج مطابقة، ثم اقتراحات قريبة (أخطاء كتابة بسيطة أو من نفس نوع المحل).
SearchResult searchPlaces(
  String query,
  List<Place> all,
  Map<String, String> categoryLabels,
) {
  final qt = _words(query);
  if (qt.isEmpty) return const SearchResult([], []);

  final hay = <Place, List<String>>{
    for (final p in all)
      p: _words('${p.name} ${categoryLabels[p.categoryId] ?? ''} ${p.sectionsText}'),
  };

  final exact = <Place>[];
  final near = <Place>[];
  for (final p in all) {
    final words = hay[p]!;
    final isExact = qt.every((t) => words.any((w) => w.contains(t)));
    if (isExact) {
      exact.add(p);
      continue;
    }
    final isNear = qt.every((t) {
      final allowed = t.length >= 6 ? 2 : (t.length >= 4 ? 1 : 0);
      return words.any((w) => w.contains(t) || _lev(w, t) <= allowed);
    });
    if (isNear) near.add(p);
  }

  exact.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
  final topExact = exact.take(6).toList();

  if (topExact.isNotEmpty) {
    final topCategory = topExact.first.categoryId;
    for (final p in all) {
      if (p.categoryId == topCategory && !topExact.contains(p) && !near.contains(p)) {
        near.add(p);
      }
    }
  }
  near.removeWhere(topExact.contains);
  near.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
  return SearchResult(topExact, near.take(4).toList());
}
